#!/usr/bin/env python3
"""Turn the inverse-design SFT file into an RL prompt dataset.

Input  : train.jsonl   (one SFT record per line, fields below)
Output : rl_train.jsonl (one RL prompt per line; verl / slime / prime-rl load this)

SFT record fields (confirmed from a sample):
    id, corpus, task_type, drug, group,
    n_tokens, n_prompt_tokens, n_completion_tokens,
    prompt, completion, text

What we keep and why:
  - prompt       -> kept verbatim. It already ends with
                    "<|im_start|>assistant\\n<think>\\n", so the model generates
                    straight from it. Do NOT re-apply a chat template on top.
  - drug         -> the real approved drug for this target. It is our anchor
                    ground truth: the reference the answer should match on
                    properties while NOT being a copy of.
  - task_type    -> routes to the right reward (A/B/C may differ).
  - completion   -> dropped from the RL prompt, but see note below: you can keep
                    it as an optional SFT-warmstart / off-policy teacher signal.

Run:
    python convert.py train.jsonl rl_train.jsonl
"""
import json
import re
import sys


def extract_final_smiles(completion: str) -> str | None:
    """Best-effort pull of the answer SMILES from an SFT completion.

    Task C explicitly asks for "a SMILES string" as the answer. The reference
    completions tend to end with the molecule. This is deliberately conservative:
    we would rather return None than a wrong parse. You will refine this once you
    eyeball ~20 completions.
    """
    # Common patterns: a fenced block, a "SMILES:" label, or a final bare token.
    m = re.search(r"SMILES[^\n:]*:\s*`?([^\s`]+)`?", completion)
    if m:
        return m.group(1).strip()
    m = re.search(r"```(?:smiles)?\s*([^\n`]+)\s*```", completion, re.IGNORECASE)
    if m:
        return m.group(1).strip()
    return None


def convert(in_path: str, out_path: str) -> None:
    n_in = n_out = 0
    by_task: dict[str, int] = {}
    with open(in_path) as fin, open(out_path, "w") as fout:
        for line in fin:
            line = line.strip()
            if not line:
                continue
            n_in += 1
            r = json.loads(line)
            task = r.get("task_type", "unknown")
            by_task[task] = by_task.get(task, 0) + 1

            ref_smiles = extract_final_smiles(r.get("completion", "")) if r.get("completion") else None

            rl = {
                # verl reads these two straight off:
                "prompt": r["prompt"],
                "data_source": f"inverse_design_{task.lower()}",
                # ground truth for the reward. We do not have a SMILES for the
                # reference drug in the data (only its name), so we carry the name
                # and, when we could parse one, the SFT answer SMILES as a hint.
                "reward_model": {
                    "style": "rule",
                    "ground_truth": json.dumps(
                        {
                            "reference_drug": r.get("drug"),
                            "reference_answer_smiles": ref_smiles,
                            "task_type": task,
                        }
                    ),
                },
                # anything the reward or later analysis may want:
                "extra_info": {
                    "id": r.get("id"),
                    "task_type": task,
                    "drug": r.get("drug"),
                    "group": r.get("group"),
                    "n_prompt_tokens": r.get("n_prompt_tokens"),
                },
            }
            fout.write(json.dumps(rl) + "\n")
            n_out += 1

    print(f"read {n_in} SFT rows -> wrote {n_out} RL prompts")
    print("by task_type:", by_task)
    print(f"out: {out_path}")


if __name__ == "__main__":
    convert(sys.argv[1] if len(sys.argv) > 1 else "train.jsonl",
            sys.argv[2] if len(sys.argv) > 2 else "rl_train.jsonl")
