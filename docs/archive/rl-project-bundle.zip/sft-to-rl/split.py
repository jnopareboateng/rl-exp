#!/usr/bin/env python3
"""Stage 2: split by drug, not by row.

    python split.py train.jsonl out_dir [--seed 0] [--val 0.1] [--test 0.1]

Writes out_dir/{train,val,test}.jsonl.

Why by `group`: several rows can describe the same drug in different wording.
A row-level split puts the same drug in train and test, so a model that has
memorised the drug looks like it generalises. Splitting whole groups keeps every
test drug unseen. The script asserts that no group appears in two files.
"""
import argparse
import json
import random
from collections import defaultdict
from pathlib import Path


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("src")
    ap.add_argument("out_dir")
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--val", type=float, default=0.1)
    ap.add_argument("--test", type=float, default=0.1)
    a = ap.parse_args()

    by_group = defaultdict(list)
    with open(a.src) as f:
        for line in f:
            if line.strip():
                r = json.loads(line)
                by_group[r["group"]].append(r)

    groups = sorted(by_group)            # sorted first so the seed alone decides the order
    random.Random(a.seed).shuffle(groups)
    n = len(groups)
    n_test = max(1, round(n * a.test))
    n_val = max(1, round(n * a.val))
    parts = {
        "test": groups[:n_test],
        "val": groups[n_test:n_test + n_val],
        "train": groups[n_test + n_val:],
    }

    seen = {}
    out = Path(a.out_dir)
    out.mkdir(parents=True, exist_ok=True)
    for name, gs in parts.items():
        with open(out / f"{name}.jsonl", "w") as f:
            rows = 0
            for g in gs:
                assert g not in seen, f"group {g!r} in both {seen[g]} and {name}"
                seen[g] = name
                for r in by_group[g]:
                    f.write(json.dumps(r) + "\n")
                    rows += 1
        print(f"{name}: {len(gs)} groups, {rows} rows")


if __name__ == "__main__":
    main()
