#!/usr/bin/env python3
"""Reward for inverse molecular design, modelled on ether0's reward server.

verl calls:  compute_score(data_source, solution_str, ground_truth, extra_info)
It returns a float in [0, 1]. slime/prime-rl wrap the same callable.

Design (tiered, cheap-to-expensive):

  Tier 0  FORMAT GATE      can we even find a molecule?        reward 0 if not
  Tier 1  VALIDITY GATE    is it a sane, drug-like molecule?   reward 0 if not
  Tier 2  PROPERTY MATCH   does it fit the requested profile?  the bulk of signal, RDKit-cheap
  Tier 3  NOVELTY          is it NOT just the reference drug?  small tie-breaker bonus
  Tier 4  BINDING (opt.)   does it actually hit the target?    SLOW oracle (docking / learned model)

Tiers 0-3 run in milliseconds on CPU and are enough to start training today.
Tier 4 is the expensive part and is where the async-RL frameworks from the survey
earn their keep (prime-rl + verifiers, AReaL online mode); leave it off until
the cheap signal is clearly moving the policy.

This file is a skeleton: the property targets in Tier 2 are placeholders. Wire
them to (a) the reference drug's RDKit descriptors, or (b) numeric constraints
parsed out of each prompt, whichever you trust more.

Needs: rdkit  (pip install rdkit)
"""
from __future__ import annotations

import json
import re

try:
    from rdkit import Chem, RDLogger
    from rdkit.Chem import Crippen, Descriptors, QED, rdMolDescriptors
    from rdkit.Chem.Fingerprints import FingerprintMols
    from rdkit import DataStructs
    RDLogger.DisableLog("rdApp.*")
    _HAVE_RDKIT = True
except Exception:  # keep importable without rdkit so you can unit-test the glue
    _HAVE_RDKIT = False


# ---------------------------------------------------------------- Tier 0: extract
def _extract_smiles(text: str) -> str | None:
    """Pull the model's final answer. Mirror whatever your generations look like.

    The model is prompted to end with a SMILES; take the LAST plausible one so
    that reasoning that mentions intermediate fragments does not fool us.
    """
    cands = re.findall(r"SMILES[^\n:]*:\s*`?([^\s`]+)`?", text)
    cands += re.findall(r"```(?:smiles)?\s*([^\n`]+)\s*```", text, re.IGNORECASE)
    cands = [c.strip() for c in cands if c.strip()]
    return cands[-1] if cands else None


# ---------------------------------------------------------------- Tier 1: validity
_BAD_SMARTS = [
    "[N+]=[N+]",           # diazo etc.  (ether0 keeps a longer BAD_SMARTS list)
    "[O-][O-]",
]

def _is_reasonable(mol) -> bool:
    """ether0's is_reasonable_molecule, trimmed. Reject degenerate / junk structures."""
    if mol is None:
        return False
    if mol.GetNumHeavyAtoms() < 6 or mol.GetNumHeavyAtoms() > 120:
        return False
    for smarts in _BAD_SMARTS:
        patt = Chem.MolFromSmarts(smarts)
        if patt and mol.HasSubstructMatch(patt):
            return False
    return True


# ---------------------------------------------------------------- Tier 2: properties
def _property_score(mol, extra_info: dict) -> float:
    """How well the molecule fits the requested property profile, in [0, 1].

    PLACEHOLDER targets below encode a generic oral small-molecule profile
    (Lipinski-ish + QED). Replace with the real per-target profile: either the
    reference drug's descriptors, or constraints you regex out of the prompt.
    Each component is a soft 0..1 band; we average them.
    """
    mw = Descriptors.MolWt(mol)
    logp = Crippen.MolLogP(mol)
    hbd = rdMolDescriptors.CalcNumHBD(mol)
    hba = rdMolDescriptors.CalcNumHBA(mol)
    tpsa = rdMolDescriptors.CalcTPSA(mol)
    qed = QED.qed(mol)

    def band(x, lo, hi):
        # 1 inside [lo,hi], ramps linearly to 0 across one band-width outside
        if lo <= x <= hi:
            return 1.0
        w = (hi - lo) or 1.0
        d = (lo - x) if x < lo else (x - hi)
        return max(0.0, 1.0 - d / w)

    comps = [
        band(mw, 250, 500),     # oral MW window
        band(logp, 1, 4),       # lipophilicity
        band(hbd, 0, 3),
        band(hba, 2, 8),
        band(tpsa, 40, 120),    # permeability window
        qed,                    # already 0..1 drug-likeness
    ]
    return sum(comps) / len(comps)


# ---------------------------------------------------------------- Tier 3: novelty
def _novelty_bonus(mol, reference_answer_smiles: str | None) -> float:
    """Small bonus for NOT being the reference drug / SFT answer.

    This is the ether0 'good_molecule_bonus' idea: among answers that already
    satisfy the profile, prefer novel ones. Keep it small so it never outweighs
    correctness.
    """
    if not reference_answer_smiles:
        return 0.0
    ref = Chem.MolFromSmiles(reference_answer_smiles)
    if ref is None:
        return 0.0
    fp1 = FingerprintMols.FingerprintMol(mol)
    fp2 = FingerprintMols.FingerprintMol(ref)
    sim = DataStructs.FingerprintSimilarity(fp1, fp2)
    # identical -> 0 bonus; quite different -> full bonus
    return max(0.0, (1.0 - sim))


# ---------------------------------------------------------------- Tier 4: binding (stub)
def _binding_score(smiles: str, extra_info: dict) -> float | None:
    """SLOW oracle. Return None to skip (recommended until cheap signal works).

    Plug in docking (AutoDock Vina / gnina) or a learned affinity model here,
    keyed on the target. Because this is seconds-to-minutes per call, run it
    behind an async reward service with a staleness budget rather than inline.
    """
    return None


# ---------------------------------------------------------------- entry point
def compute_score(data_source=None, solution_str: str = "", ground_truth: str = "", extra_info=None):
    extra_info = extra_info or {}
    try:
        gt = json.loads(ground_truth) if isinstance(ground_truth, str) else (ground_truth or {})
    except Exception:
        gt = {}

    if not _HAVE_RDKIT:
        raise RuntimeError("rdkit not installed; `pip install rdkit`")

    smi = _extract_smiles(solution_str)
    if not smi:
        return 0.0                                   # Tier 0 gate
    mol = Chem.MolFromSmiles(smi)
    if not _is_reasonable(mol):
        return 0.0                                   # Tier 1 gate

    prop = _property_score(mol, extra_info)          # Tier 2  (0..1)
    nov = _novelty_bonus(mol, gt.get("reference_answer_smiles"))  # Tier 3 (0..1)

    reward = 0.9 * prop + 0.1 * nov                  # weight: correctness dominates

    binding = _binding_score(smi, extra_info)        # Tier 4 (optional)
    if binding is not None:
        reward = 0.5 * reward + 0.5 * binding

    return float(max(0.0, min(1.0, reward)))


if __name__ == "__main__":
    # tiny smoke test
    demo = "...reasoning... SMILES: CC(=O)Oc1ccccc1C(=O)O"
    print("aspirin-like demo reward:",
          compute_score("inverse_design_c", demo,
                        json.dumps({"reference_answer_smiles": "CC(=O)Oc1ccccc1C(=O)O"}), {}))
